package com.example.rachadmoumni.xyz;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //قمت بعمل هذا المتغير من اجل ان يكون عداد لتغير الاندكس داخل القائمه
    int t;
    // متغير  من نوع كائن textview
    TextView t1;
    // متغير من نوع arry string
    String[] mtary;


    //هاته اول داله تنفذ عند تشغيل البرنامج
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //هذا الكود من اجل  منع تدوير الشاشه
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // بدايه المتغير عند تشغيل البرنامج تساوي الصفر
        t = 0;
        t1 = (TextView) findViewById(R.id.textView);
        mtary = getResources().getStringArray(R.array.ty);
        t1.setText(mtary[0]);

    }

    //يتم تنفيذ الداله عند الضغط علي زر السابق
    public void last(View view) {
        //هذا الشرط يقوم بالتحقق من ان قميه المتفير اكبر من الواحد
        // خوفا من القيم السالبه
        if (t > 1) {
            t = t - 1;
            final TextView t2 = (TextView) findViewById(R.id.textView2);
            t2.setText("حكمة رقم" + t + "من500 حكمة");
            t1 = (TextView) findViewById(R.id.textView);
            mtary = getResources().getStringArray(R.array.ty);
            t1.setText(mtary[t]);
        } else {
        }
        //نهايه الداله
    }

    //يتم تنفيذ الداله عند الضغط علي زر التالي
    public void next(View view) {
        mtary = getResources().getStringArray(R.array.ty);
        //يقوم هذاالشرط بالتحقق من قيمه المتغير كي لاتكون اكبر من طول الجدول
        if (t < mtary.length - 1) {
            t = t + 1;
            final TextView t2 = (TextView) findViewById(R.id.textView2);
            t2.setText("حكمة رقم" + t + "من500 حكمة");
            t1 = (TextView) findViewById(R.id.textView);
            //يتم هنا ربط الجدول بالمتغبر وعرضه
            mtary = getResources().getStringArray(R.array.ty);
            t1.setText(mtary[t]);
        } else {
            //اذا كان الشرط السابق  غير  محقق لا يتم تنفيذ شىء
        }
    }

    //يتم تشغيل هاته الداله عند الضغط علي زر البحث
    public void cher(View view) {
        EditText e1 = (EditText) findViewById(R.id.editText);
        //قمت بوضع هذا الشرط من اجل التحقق من ان الاديت ليست فارغه
        if (e1.getText().toString().equals("")) {
            //اذا كانت فارغه يتم الرجوع دون تنفيذ اي شيء
            return;
        } else {
            //اذا كانت تختلف عن الفراغ  يتم التنفيذ

            t = Integer.parseInt(String.valueOf(e1.getText()));
            mtary = getResources().getStringArray(R.array.ty);
            //هنا يتحقق من ان قيمه المتغير ليست اكبر من طول الجدول
            if (t < mtary.length) {
                //اذا كان الشرط صحيح يتم  التنفيذ
                final TextView t2 = (TextView) findViewById(R.id.textView2);
                t2.setText("حكمة رقم" + t + "من500 حكمة");
                t1 = (TextView) findViewById(R.id.textView);
                mtary = getResources().getStringArray(R.array.ty);
                t1.setText(mtary[t]);
            } else {
                //واذا لم يتحقق الشرط السابق
                //يعرض رساله للمستخدم ان  الرقم غير موجود
                Toast mytoast = new Toast(this);
                mytoast.makeText(MainActivity.this, "اسف لايوجد هذا الرقم ", Toast.LENGTH_LONG).show();

            }
            //نهايه الشرط
        }
        //نهايه الداله
    }
}

// نهايه البرنامج
